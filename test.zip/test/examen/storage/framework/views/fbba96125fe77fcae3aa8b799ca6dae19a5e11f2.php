<div>
    <form wire:submit.prevent="crear">

    <div class="text-center card">
        <div class="card-header">
            Crear Empleado
        </div>
        <div class="card-body">
            <?php echo $__env->make('livewire.empleados.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="card-footer text-muted">
        <button wire:click="crear"  class="btn btn-success btn-sm">Crear</button>
        <a href="<?php echo e(route('empleados.index')); ?>"  class="btn btn-secondary btn-sm ">Cancelar</a>
    </div>
    </div>

</form>
</div>
<?php /**PATH C:\Users\kevin\Documents\laravel\examen\resources\views/livewire/empleados/create-empleados.blade.php ENDPATH**/ ?>
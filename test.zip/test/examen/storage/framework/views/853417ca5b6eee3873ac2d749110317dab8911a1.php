<div>
    <div class="text-center card mx-auto" style="width: 18rem;">
        <img src="http://assets.stickpng.com/images/585e4bf3cb11b227491c339a.png" class="card-img-top" alt="...">
        <div class="card-body">
          <h5 class="card-title"><?php echo e($empleado->primernombre); ?> <?php echo e($empleado->segundonombre); ?> <?php echo e($empleado->apellidomaterno); ?> <?php echo e($empleado->apellidopaterno); ?></h5>
          <p class="card-text"><?php echo e($empleado->puesto); ?></p>
          <button wire:click="eliminar" class="btn btn-danger">Eliminar</button>
          <a href="<?php echo e(route('empleados.index')); ?>" class="btn btn-secondary">Cancelar</a>
        </div>
      </div>
</div>
<?php /**PATH C:\Users\HP\Desktop\archivos\Cuatrimestres\Ingenieria\9 Cuatrimestre\Desarrollo web integral\Unidad 2\examen\resources\views/livewire/empleados/eliminar-empleados.blade.php ENDPATH**/ ?>
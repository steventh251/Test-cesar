<div class="container">
    <a type="button" class="btn btn-success mb-3 float-right" href="<?php echo e(route('empleados.create')); ?>"><i class="fas fa-user-plus"></i> Crear</a>
    <h1 class="text-center float-center">EMPLEADOS</h1>
    <table class="table">
        <thead>
          <tr>
            <th scope="col">ID</th>
            <th scope="col">Primer Nombre</th>
            <th scope="col">Segundo Nombre</th>
            <th scope="col">Apellido Paterno</th>
            <th scope="col">Apellido Materno</th>
            <!--<th scope="col">Sexo</th> -->
            <th scope="col">Fecha de Nacimiento</th>
            <th scope="col">Estado</th>
            <th scope="col">Facebook</th>
            <th scope="col">Telefono</th>
            <th scope="col">Acciones</th>
          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $empleados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <tr>
            <th scope="row">1</th>
            <td><?php echo e($empleado->primernombre); ?></td>
            <td><?php echo e($empleado->segundonombre); ?></td>
            <td><?php echo e($empleado->apellidopaterno); ?></td>
            <td><?php echo e($empleado->apellidomaterno); ?></td>
            <!--<td><?php echo e($empleado->sexo); ?></td> -->
            <td><?php echo e($empleado->fechanacimiento); ?></td>
            <td><?php echo e($empleado->estado); ?></td>
            <td><?php echo e($empleado->facebook); ?></td>
            <td><?php echo e($empleado->telefono); ?></td>
            <td>
                <button type="button" class="btn btn-primary  btn-sm" href="#"><i class="fas fa-eye"></i></button>
                <a type="button" class="btn btn-warning btn-sm " href="<?php echo e(route('empleados.editar',$empleado)); ?>"><i class="fas fa-user-edit"></i></a>
                <a type="button" class="btn btn-danger   btn-sm" href="<?php echo e(route('empleados.eliminar',$empleado)); ?>"><i class="fas fa-user-times"></i></a>
            </td>

          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
      <?php echo e($empleados->links()); ?>


    </div>
<?php /**PATH C:\Users\HP\Desktop\archivos\Cuatrimestres\Ingenieria\9 Cuatrimestre\Desarrollo web integral\Unidad 2\examen\resources\views/livewire/empleados/index-empleados.blade.php ENDPATH**/ ?>
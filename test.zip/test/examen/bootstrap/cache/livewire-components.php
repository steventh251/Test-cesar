<?php return array (
  'empleados.create-empleados' => 'App\\Http\\Livewire\\Empleados\\CreateEmpleados',
  'empleados.editar-empleados' => 'App\\Http\\Livewire\\Empleados\\EditarEmpleados',
  'empleados.eliminar-empleados' => 'App\\Http\\Livewire\\Empleados\\EliminarEmpleados',
  'empleados.index-empleados' => 'App\\Http\\Livewire\\Empleados\\IndexEmpleados',
);
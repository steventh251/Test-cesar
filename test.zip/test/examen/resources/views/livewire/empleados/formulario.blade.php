
<div class="row" style="background: #7EF761 ">
    <div class="col-6 mx-auto">
        <div class="form-group">
          <label><b>Primer Nombre:</b></label>
          <input wire:model = "empleado.primernombre"  class="form-control">
          @error('empleado.primernombre') <span class="text-danger">{{$message}}</span> @enderror

        </div>
        <div class="form-group">
            <label><b> Nombre:</b></label>
            <input wire:model = "empleado.segundonombre" type="text" class="form-control">
            @error('empleado.segundonombre') <span class="text-danger">{{$message}}</span> @enderror

          </div>
          <div class="form-group">
            <label><b>Apellido Paterno:</b></label>
            <input wire:model = "empleado.apellidopaterno" type="text" class="form-control">
            @error('empleado.apellidopaterno') <span class="text-danger">{{$message}}</span> @enderror
          </div>
          <div class="form-group">
            <label><b>Apellido Materno</b></label>
            <input wire:model = "empleado.apellidomaterno" type="text" class="form-control">
            @error('empleado.apellidomaterno') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>Fecha de Nacimiento</b></label>
            <input wire:model = "empleado.fechanacimiento" type="date" class="form-control">
            @error('empleado.fechanacimiento') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>Puesto De Trabajo</b></label>
            <input wire:model = "empleado.puesto" type="text" class="form-control">
            @error('empleado.puesto') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>CURP</b></label>
            <input wire:model = "empleado.curp" type="text" class="form-control">
            @error('empleado.curp') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>RFC</b></label>
            <input wire:model = "empleado.rfc" type="text" class="form-control">
            @error('empleado.rfc') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>Estado</b></label>
            <input wire:model = "empleado.estado" type="text" class="form-control">
            @error('empleado.estado') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>Codigo Postal</b></label>
            <input wire:model = "empleado.codigopostal" type="number" class="form-control">
            @error('empleado.codigopostal') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>Salario</b></label>
            <input wire:model = "empleado.salario" type="number" class="form-control">
            @error('empleado.salario') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>Correo Electronico</b></label>
            <input wire:model = "empleado.correo" type="text" class="form-control">
            @error('empleado.correo') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>Horario de Trabajo</b></label>
            <input wire:model = "empleado.horario" type="text" class="form-control">
            @error('empleado.horario') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>Area de Trabajo</b></label>
            <input wire:model = "empleado.areatrabajo" type="text" class="form-control">
            @error('empleado.areatrabajo') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>Facebook</b></label>
            <input wire:model = "empleado.facebook" type="text" class="form-control">
            @error('empleado.facebook') <span class="text-danger">{{$message}}</span> @enderror
        </div>
        <div class="form-group">
            <label><b>Telefono</b></label>
            <input wire:model = "empleado.telefono" type="number" class="form-control">
            @error('empleado.telefono') <span class="text-danger">{{$message}}</span> @enderror
        </div>


    </div>
</div>

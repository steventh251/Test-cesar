<?php

namespace App\Http\Livewire\Peliculas;


use App\Models\Peliculas;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;
use Livewire\WithFileUploads;

class CreatePeliculas extends Component
{
    public function mount(){
        $this->peliculas = new  Peliculas();
    }
    use WithFileUploads;
    public Peliculas $peliculas;
    public $foto;

    public function render()
        {
            return view('livewire.peliculas.create-peliculas');
        }
    public function create()
    {
        $this->validate();
        if($this->foto != null){
        $this->peliculas->foto = Storage::disk('public')->put('images/peliculas',$this->foto);
        }
        $this->peliculas->save();
        return redirect(route('indexPeliculas'));

    }
    protected function rules(){

        return rules::rulesPeliculas();
    }

}

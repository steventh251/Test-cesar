<?php

namespace App\Http\Livewire\Peliculas;

class rules
{
    public static function rulesPeliculas(){
        return [
            'peliculas.nombre'=> 'required',
            'peliculas.genero'=> 'required',
            'peliculas.año'=>'required|numeric',
            'peliculas.precio'=>'required|numeric',
            'foto'=>'nullable|image'
            ];
    }

}

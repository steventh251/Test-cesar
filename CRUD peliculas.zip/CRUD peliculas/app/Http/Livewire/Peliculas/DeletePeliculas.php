<?php

namespace App\Http\Livewire\Peliculas;


use App\Models\Peliculas;
use Livewire\Component;

class DeletePeliculas extends Component
{
    public Peliculas $peliculas;
    public function render()
    {
        return view('livewire.peliculas.delete-peliculas');
    }
    public function delete(){
        $this->peliculas->delete();
        return redirect(route('indexPeliculas'));
    }
}

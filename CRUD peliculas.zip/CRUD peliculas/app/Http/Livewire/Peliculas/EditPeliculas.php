<?php

namespace App\Http\Livewire\Peliculas;

use App\Models\Peliculas;
use Illuminate\Support\Facades\Storage;
use Livewire\Component;

class EditPeliculas extends Component
{
    public Peliculas $peliculas;
    public $foto;

    public function render()
    {
        return view('livewire.peliculas.edit-peliculas');
    }
    public function edit(){
        $this->validate();
        if($this->foto != null){
            if($this->peliculas->foto !=null){
                Storage::disk('public')->delete($this->peliculas->foto);
            }
            $this->peliculas->foto = Storage::disk('public')->put('images/peliculas',$this->foto);
        }
        $this->peliculas->save();
        return redirect(route('indexPeliculas'));
    }
    protected function rules(){
        return rules::rulesPeliculas();
    }
}

<?php

namespace App\Http\Livewire\Peliculas;

use App\Models\Peliculas;
use Livewire\Component;

class ShowPeliculas extends Component
{
    public Peliculas $peliculas;
    public function render()
    {
        return view('livewire.peliculas.show-peliculas');
    }
}

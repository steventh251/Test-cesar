<div>
    <form wire:submit.prevent="edit">
        <div class="card">
            <div class="card-header">
                Editar usuario
            </div>
            <div class="card-body">
                <?php echo $__env->make('livewire.usuarios.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </div>
            <div class="card-footer text-center">
                <button wire:click="edit" type="submit" class="btn btn-primary"><i class="fa fa-save"></i>
                    Guardar</button>
                <a href="<?php echo e(route('indexUsuarios')); ?>" class="btn btn-danger">Cancelar</a>
            </div>
        </div>




    </form>

</div>
<?php /**PATH C:\Users\cmste\Desktop\CRUD peliculas\resources\views/livewire/usuarios/edit-usuario.blade.php ENDPATH**/ ?>
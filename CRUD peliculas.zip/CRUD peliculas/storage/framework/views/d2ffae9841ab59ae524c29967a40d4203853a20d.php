<div>
    <form wire:submit.prevent="create">
        <div class="card">
            <div class="card-header">
                Nuevo Libro
            </div>
            <div class="card-body">
                <?php echo $__env->make('livewire.libros.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </div>
            <div class="card-footer text-center">
                <button wire:click="create" type="submit" class="btn btn-success">Crear</button>
                <a href="<?php echo e(route('indexLibros')); ?>" class="btn btn-danger">Regresar</a>
            </div>
        </div>




    </form>

</div>
<?php /**PATH C:\Users\kevin\Documents\laravel\Finish\resources\views/livewire/libros/create-libro.blade.php ENDPATH**/ ?>
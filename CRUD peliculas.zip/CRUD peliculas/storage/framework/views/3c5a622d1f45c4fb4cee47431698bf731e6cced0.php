<div>
    <div class="row ">
        <div class="col-6 mx-auto text-center">
            <div class=" card">

                <div class="card-header">
                </div>
                <div class="card-body">
                    <h1><?php echo e($libro->nombrel); ?></h1>
                    <?php echo e($libro->autor); ?> <?php echo e($libro->año); ?>

                </div>
                <div class="card-footer">
                    <button wire:click="delete" type="submit" class="btn btn-danger">Eliminar</button>
                    <a href="<?php echo e(route('indexLibros')); ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\kevin\Documents\laravel\Finish\resources\views/livewire/libros/delete-libro.blade.php ENDPATH**/ ?>
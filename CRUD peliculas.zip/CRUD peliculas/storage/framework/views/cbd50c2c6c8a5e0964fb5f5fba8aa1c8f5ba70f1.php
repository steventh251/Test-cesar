<div wire:init="cargando">

    <div class="row mb-3">
        <div class="col-3">
            <div class="input-group">
                <span class="input-group-text" id="addon-wrapping"><i class="fa fa-search"></i></span>
                <input wire:model="search" type="search" class="form-control" placeholder="Buscar..."
                    aria-labaria-describedby="addon-wrapping">
            </div>
        </div>
        <div class="col-9 ">
            <a href="<?php echo e(route('createBicicletas')); ?>" class="btn btn-success float-right">Nuevo <i
                    class="fas fa-plus-square"></i></a>
        </div>
    </div>
    <?php if(count($bicicletas) > 0): ?>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Foto</th>
                    <th scope="col">Marca</th>
                    <th scope="col">Modelo</th>
                    <th scope="col">Año</th>
                    <th scope="col">Precio</th>
                    <th scope="col">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $bicicletas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bicicleta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <th scope="row"><?php echo e($bicicleta->id); ?></th>
                        <td><img style="width: 50px; height:70px"
                                src="<?php echo e(Storage::disk('public')->url($bicicleta->foto != null ? $bicicleta->foto : 'images/bicicletas/default.png')); ?>"
                                alt=""></td>
                        <td><?php echo e($bicicleta->marca); ?></td>
                        <td><?php echo e($bicicleta->modelo); ?></td>
                        <td><?php echo e($bicicleta->año); ?></td>
                        <td><?php echo e($bicicleta->precio); ?>€</td>
                        <td>
                            <a title="Ver bicicleta" style="font-size: 1.3rem" class="text-info mr-1"
                                href="<?php echo e(route('showBicicletas', $bicicleta)); ?>"><i class="fas fa-eye"></i></a>
                            <a title="Editar bicicleta" style="font-size: 1.3rem" class="text-warning mr-1"
                                href="<?php echo e(route('editBicicletas', $bicicleta)); ?>"><i class="fas fa-edit"></i></a>
                            <a wire:click="delete title=" Eliminar bicicleta" style="font-size: 1.3rem"
                                class="text-danger mr-1" href="<?php echo e(route('deleteBicicletas', $bicicleta)); ?>"><i
                                    class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    <?php else: ?>
        <img class="d-block mx-auto" src="<?php echo e(Storage::disk('public')->url('images/otros/loading.gif')); ?>" alt="">

        <h2 class="text-center">Cargando...</h2>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\kevin\Documents\laravel\KevinBicicleta\resources\views/livewire/bicicletas/index-bicicletas.blade.php ENDPATH**/ ?>
<div>
    <div class="row ">
        <div class="col-6 mx-auto text-center">
            <div class=" card">

                <div class="card-body">
                    <h1><?php echo e($bicicleta->marca); ?></h1>
                    <?php echo e($bicicleta->modelo); ?> <?php echo e($bicicleta->año); ?>

                </div>
                <div class="card-footer">
                    <button wire:click="delete" type="submit" class="btn btn-danger">Eliminar</button>
                    <a href="<?php echo e(route('indexBicicletas')); ?>" class="btn btn-secondary">Cancelar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\kevin\Documents\laravel\KevinBicicleta\resources\views/livewire/bicicletas/delete-bicicletas.blade.php ENDPATH**/ ?>
<div wire:init="cargando">

    <div class="row mb-3">
        <div class="col-3">
            <div class="input-group">
                <span class="input-group-text" id="addon-wrapping"><i class="fa fa-search"></i></span>
                <input wire:model="search" type="search" class="form-control" placeholder="Buscar..."
                    aria-labaria-describedby="addon-wrapping">
            </div>
        </div>
        <div class="col-9 ">
            <a href="<?php echo e(route('createLibros')); ?>" class="btn btn-success float-right">Nuevo <i
                    class="fas fa-plus-square"></i></a>
        </div>
    </div>
    <?php if(count($libros) > 0): ?>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Foto</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Autor</th>
                    <th scope="col">Año</th>
                    <th scope="col">Precio</th>
                    <th scope="col">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $libros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $libro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <tr>
                        <th scope="row"><?php echo e($libro->id); ?></th>
                        <td><img style="width: 50px; height:70px"
                                src="<?php echo e(Storage::disk('public')->url($libro->foto != null ? $libro->foto : 'images/libros/default.png')); ?>"
                                alt=""></td>
                        <td><?php echo e($libro->nombrel); ?></td>
                        <td><?php echo e($libro->autor); ?></td>
                        <td><?php echo e($libro->año); ?></td>
                        <td><?php echo e($libro->precio); ?>€</td>
                        <td>
                            <a title="Ver Libro" style="font-size: 1.3rem" class="text-info mr-1"
                                href="<?php echo e(route('showLibros', $libro)); ?>"><i class="fas fa-eye"></i></a>
                            <a title="Editar Libro" style="font-size: 1.3rem" class="text-warning mr-1"
                                href="<?php echo e(route('editLibros', $libro)); ?>"><i class="fas fa-pen"></i></a>
                            <a wire:click="delete title=" Eliminar Libro" style="font-size: 1.3rem"
                                class="text-danger mr-1" href="<?php echo e(route('deleteLibros', $libro)); ?>"><i
                                    class="fas fa-trash-alt"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    <?php else: ?>
        <img class="d-block mx-auto" src="<?php echo e(Storage::disk('public')->url('images/otros/loading.gif')); ?>" alt="">

        <h2 class="text-center">Cargando...</h2>
    <?php endif; ?>
</div>
<?php /**PATH C:\Users\kevin\Documents\laravel\Finish\resources\views/livewire/libros/index-libros.blade.php ENDPATH**/ ?>
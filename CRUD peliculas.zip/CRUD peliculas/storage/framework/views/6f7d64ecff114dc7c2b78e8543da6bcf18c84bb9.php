<div>
    <div class="row">

        <div class="col-6 pr-0">
            <img class="d-block float-right" style="width:265px; height:405px"
                src="<?php echo e(Storage::disk('public')->url($libro->foto)); ?>" alt="">
        </div>

        <div class="col-6 pl-0">
            <div style="width:265px; height:405px; border:.5px solid #d1d1d1" class="card text-center">
                <div class="card-tittle">
                    <h2>Informacion del Libro</h2>
                </div>
                <div class="card-header">
                </div>
                <div class="card-body">
                    <h1><?php echo e($libro->nombrel); ?></h1>
                    <?php echo e($libro->autor); ?> , <?php echo e($libro->año); ?>

                    <h2 class="mt-5"><?php echo e($libro->precio); ?>€</h2>
                </div>
                <div class="card-footer text-muted">
                    <a href="<?php echo e(route('editLibros', $libro)); ?>" type="submit" class="btn btn-success">Editar</a>
                    <a href="<?php echo e(route('indexLibros')); ?>" class="btn btn-danger">Regresar</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\kevin\Documents\laravel\Finish\resources\views/livewire/libros/show-libro.blade.php ENDPATH**/ ?>
<div wire:init="cargando">

    <div class="row mb-3">
        <div class="col-3">
            <div class="input-group">
                <span class="input-group-text" id="addon-wrapping"><i class="fa fa-search"></i></span>
                <input wire:model="search" type="search" class="form-control" placeholder="Buscar..."
                    aria-labaria-describedby="addon-wrapping">
            </div>
        </div>
        <div class="col-9 ">
            <a href="<?php echo e(route('createUsuarios')); ?>" class="btn btn-success float-right">Nuevo <i
                    class="fas fa-plus-square"></i></a>
        </div>
    </div>
    <?php if(count($usuarios) > 0): ?>

        <table class="table">
            <thead>
                <tr>
                    <th scope="col">ID</th>
                    <th scope="col">Foto</th>
                    <th scope="col">Nombre</th>
                    <th scope="col">Correo</th>
                    <th scope="col">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($usuario->id); ?></th>
                        <td><img style="width: 50px; height:50px"
                                src="<?php echo e(Storage::disk('public')->url($usuario->foto != null ? $usuario->foto : 'images/usuarios/default.png')); ?>"
                                alt=""></td>
                        <td><?php echo e($usuario->nombre_usuario); ?></td>
                        <td><?php echo e($usuario->email); ?></td>
                        <td>
                            <a title="Ver usuario" style="font-size: 1.3rem" class="text-info mr-1"
                                href="<?php echo e(route('showUsuarios', $usuario)); ?>"><i class="fas fa-eye"></i></a>
                            <a title="Editar usuario" style="font-size: 1.3rem" class="text-warning mr-1"
                                href="<?php echo e(route('editUsuarios', $usuario)); ?>"><i class="fas fa-edit"></i></a>
                            <a wire:click="delete title=" Eliminar usuario" style="font-size: 1.3rem"
                                class="text-danger mr-1" href="<?php echo e(route('deleteUsuarios', $usuario)); ?>"><i
                                    class="fas fa-trash"></i></a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>

    <?php else: ?>
        <img class="d-block mx-auto" src="<?php echo e(Storage::disk('public')->url('images/otros/loading.gif')); ?>" alt="">

        <h2 class="text-center">Cargando...</h2>
    <?php endif; ?>
</div>

<?php /**PATH C:\Users\kevin\Documents\laravel\KevinBicicleta\resources\views/livewire/usuarios/index-usuarios.blade.php ENDPATH**/ ?>
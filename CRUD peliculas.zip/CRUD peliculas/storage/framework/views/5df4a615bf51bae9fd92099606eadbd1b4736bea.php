<div>
    <form wire:submit.prevent="create">
        <div class="card">
            <div class="card-header">
                Nuevo bicicleta
            </div>
            <div class="card-body">
                <?php echo $__env->make('livewire.bicicletas.formulario', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
            </div>
            <div class="card-footer text-center">
                <button wire:click="create" type="submit" class="btn btn-success">Crear</button>
                <a href="<?php echo e(route('indexBicicletas')); ?>" class="btn btn-danger">Regresar</a>
            </div>
        </div>




    </form>

</div>
<?php /**PATH C:\Users\kevin\Documents\laravel\KevinBicicleta\resources\views/livewire/bicicletas/create-bicicletas.blade.php ENDPATH**/ ?>
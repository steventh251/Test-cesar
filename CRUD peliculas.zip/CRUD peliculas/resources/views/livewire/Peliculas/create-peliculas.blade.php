<div>
    <form wire:submit.prevent="create">
        <div class="card">
            <div class="card-header">
                Nueva pelicula
            </div>
            <div class="card-body">
                @include('livewire.peliculas.formulario')
            </div>
            <div class="card-footer text-center">
                <button wire:click="create" type="submit" class="btn btn-success">Crear</button>
                <a href="{{ route('indexPeliculas') }}" class="btn btn-danger">Regresar</a>
            </div>
        </div>




    </form>

</div>
